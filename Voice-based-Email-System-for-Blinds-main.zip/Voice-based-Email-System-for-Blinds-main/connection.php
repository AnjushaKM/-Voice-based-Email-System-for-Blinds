<?php

$con = mysqli_connect("localhost","root","","voice_email");

?>